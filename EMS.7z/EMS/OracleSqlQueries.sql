DROP TABLE EMPLOYEE CASCADE CONSTRAINTS;


CREATE TABLE Employee(
	id int,
	name varchar2(20),
	department varchar2(20),
	designation varchar2(20),
	dateOfBirth varchar2(10),
	dateOfJoining varchar2(10),
	salary float
	);
	
	
DROP TABLE EMSUsers CASCADE CONSTRAINTS;

create table EMSUsers(
	id number,
	username varchar2(20),
	password varchar2(20));
	
	
create sequence emsusers_seq start with 1;

insert into EMSUsers values(emsusers_seq.nextval, 'lalak','pass@123');

commit;

create sequence employeeid_seq start with 1000;