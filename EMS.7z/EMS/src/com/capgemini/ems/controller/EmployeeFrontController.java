package com.capgemini.ems.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.exception.UserException;
import com.capgemini.ems.service.EmployeeService;
import com.capgemini.ems.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeFrontController
 */
@WebServlet("/EmployeeFrontController")
public class EmployeeFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private EmployeeService employeeService;
	
	public EmployeeFrontController() {
		employeeService=new EmployeeServiceImpl(); //association
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */


	protected void doGet(HttpServletRequest request, 

			HttpServletResponse response) throws ServletException, 

			IOException {
		processRequest(request,response);
	}


	protected void doPost(HttpServletRequest 

			request, HttpServletResponse response) throws 

			ServletException, IOException {
		processRequest(request,response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse 

			response) throws ServletException, IOException {
		
		HttpSession usersession=request.getSession(false);
		
		if(usersession==null){
			RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
			request.setAttribute("errorMessage", "you need to login to this page.<a href='Login.jsp'>click here</a> to login.");
			rd.forward(request, response);
			return;
		}	
		
		String action= request.getParameter("action");
		
		switch(action){
		
		case "add":
		{
			//String id=request.getParameter("id");
			String name=request.getParameter("name");
			String department=request.getParameter("department");
			String designation=request.getParameter("designation");
			String dateOfBirth=request.getParameter("dateOfBirth");
			String dateOfJoining=request.getParameter("dateOfJoining");
			String salary=request.getParameter("salary");
			
			HashMap<String,String> empDetails=new HashMap<>();
			
			//empDetails.put("id",           id);
			empDetails.put("name",         name);
			empDetails.put("department",   department);
			empDetails.put("designation",  designation);
			empDetails.put("dateOfBirth",  dateOfBirth);
			empDetails.put("dateOfJoining",dateOfJoining);
			empDetails.put("salary",       salary);
			
			try {
				employeeService.addEmployee(empDetails);
				RequestDispatcher rd=request.getRequestDispatcher("Menu.jsp");
				rd.forward(request, response);
				break;
			}
			catch (EmployeeException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}
			
			
		}
		
		case "fetch":
		{
			
			String id=request.getParameter("id");
			try {
				HashMap<String,String> empDetails=employeeService.searchEmployee(id);
				
				RequestDispatcher rd=request.getRequestDispatcher("UpdateEmployee.jsp");
				request.setAttribute("empDetails", empDetails);
				rd.forward(request, response);
				break;
				
			} catch (EmployeeException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}
			
		}
		
		case "update":
		{
			String id=request.getParameter("id");
			String name=request.getParameter("name");
			String department=request.getParameter("department");
			String designation=request.getParameter("designation");
			String dateOfBirth=request.getParameter("dateOfBirth");
			String dateOfJoining=request.getParameter("dateOfJoining");
			String salary=request.getParameter("salary");
			
			HashMap<String,String> empDetails=new HashMap<>();
			
			empDetails.put("id",           id);
			empDetails.put("name",         name);
			empDetails.put("department",   department);
			empDetails.put("designation",  designation);
			empDetails.put("dateOfBirth",  dateOfBirth);
			empDetails.put("dateOfJoining",dateOfJoining);
			empDetails.put("salary",       salary);
			

			try {
				employeeService.updateEmployee(empDetails);
				RequestDispatcher rd=request.getRequestDispatcher("Menu.jsp");
				rd.forward(request, response);
				break;
			}
			catch (EmployeeException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}
			
			
		}
		
		case "search":
		{
			String id=request.getParameter("id");
			try {
				HashMap<String,String> empDetails=employeeService.searchEmployee(id);
				
				RequestDispatcher rd=request.getRequestDispatcher("SearchEmployee.jsp");
				request.setAttribute("empDetails", empDetails);
				rd.forward(request, response);
				break;
				
			} catch (EmployeeException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}
			
			
		}
		
		case "remove":
		{
			String id=request.getParameter("id");
			try {
				employeeService.removeEmployee(id);
				
				RequestDispatcher rd=request.getRequestDispatcher("Menu.jsp");
				
				rd.forward(request, response);
				break;
				
			} catch (EmployeeException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}
			
		}
		
		case "showall":
		{
			try {
				List<HashMap<String, String>> employees=employeeService.getAllEmployees();
				
				RequestDispatcher rd=request.getRequestDispatcher("ViewEmployee.jsp");
				request.setAttribute("employees", employees);
				rd.forward(request, response);
				break;
			} catch (EmployeeException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}	
		}
		
		case "Login":
		{
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			
			try {
				if(employeeService.validateUser(username, password)
						==true)
				{
					HttpSession session=request.getSession(true);
					
					session.setAttribute("username", username);
					
					RequestDispatcher rd=
							request.getRequestDispatcher("Menu.jsp");
					
					rd.forward(request, response);
					break;
				}
				else{
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", 
							"User with username"+username+"does not exists");
					rd.forward(request, response);
					break;
					
				}
			} catch (UserException e) {
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
				break;
			}
		}
		case "Logout":
		{
			HttpSession session=request.getSession(false);
			
			if(session !=null)
			{
				session.invalidate();
			}
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
			break;
			
		}
		default:
		{
			RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
			request.setAttribute("errorMessage", 
					"the page you requested does not exists");
			rd.forward(request, response);
			break;
		}
		}
	}

}
