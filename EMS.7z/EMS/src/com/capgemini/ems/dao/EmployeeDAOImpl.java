package com.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.factory.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public void addEmployee(Employee emp) throws EmployeeException {
		try(Connection con=DBUtil.getConnection())
		{
			PreparedStatement pstm=
					con.prepareStatement("INSERT INTO Employee VALUES(employeeid_seq.nextval,?,?,?,?,?,?)");
			
			//pstm.setInt(1,emp.getId());
			pstm.setString(1,emp.getName());
			pstm.setString(2,emp.getDepartment());
			pstm.setString(3,emp.getDesignation());
			pstm.setString(4,emp.getDateOfBirth());
			pstm.setString(5,emp.getDateOfJoining());
			pstm.setFloat(6,emp.getSalary());
			
			pstm.executeUpdate();
			
		}catch(Exception e){
			throw new EmployeeException(e);
			
		}

	}

	@Override
	public void updateEmployee(Employee emp) throws EmployeeException {
		try(Connection con=DBUtil.getConnection())
		{
			PreparedStatement pstm=
					con.prepareStatement("UPDATE Employee SET name=?,department=?,designation=?,dateOfBirth=?,dateOfJoining=?,salary=? where id=?");
			
			pstm.setString(1,emp.getName());
			pstm.setString(2,emp.getDepartment());
			pstm.setString(3,emp.getDesignation());
			pstm.setString(4,emp.getDateOfBirth());
			pstm.setString(5,emp.getDateOfJoining());
			pstm.setFloat(6,emp.getSalary());
			pstm.setInt(7,emp.getId());
			
			pstm.executeUpdate();
			
		}catch(Exception e){
			throw new EmployeeException(e);
			
		}
		
	

	}

	@Override
	public Employee searchEmployee(Employee emp) throws EmployeeException {
	
		try(Connection con=DBUtil.getConnection())
		{
		PreparedStatement pstm=
				con.prepareStatement("SELECT * FROM Employee WHERE id=?");
		pstm.setInt(1, emp.getId());
		ResultSet res= pstm.executeQuery();
		
		if(res.next() != true)
			throw new EmployeeException("employee id not found with id "+emp.getId());
		
		else{
			
			emp.setName(res.getString("name"));
			emp.setDepartment(res.getString("department"));
			emp.setDesignation(res.getString("designation"));
			emp.setDateOfBirth(res.getString("dateOfBirth"));
			emp.setDateOfJoining(res.getString("dateOfJoining"));
			emp.setSalary(res.getFloat("salary"));
			return emp;
		}
		}catch(Exception e){
			throw new EmployeeException(e);
			
		}
		
		
	}

	@Override
	public void removeEmployee(Employee emp) throws EmployeeException {
		try(Connection con=DBUtil.getConnection())
		{
			try
			{
				searchEmployee(emp);
			}catch(Exception e){
				throw new EmployeeException(e.getMessage());
				
			}
		PreparedStatement pstm=
				con.prepareStatement("DELETE FROM Employee WHERE id=?");
		pstm.setInt(1, emp.getId());
		
		pstm.execute();
		
		}catch(Exception e){
			throw new EmployeeException(e);
			
		}
		
		

	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		List<Employee> employees=new ArrayList<Employee>();
		
		try(Connection con=DBUtil.getConnection())
		{
			Statement stml=con.createStatement();
			ResultSet res=stml.executeQuery("SELECT * FROM Employee");
			while(res.next()){
				Employee emp=new Employee(); 
				
				emp.setId(res.getInt("id"));
				emp.setName(res.getString("name"));
				emp.setDepartment(res.getString("department"));
				emp.setDesignation(res.getString("designation"));
				emp.setDateOfBirth(res.getString("dateOfBirth"));
				emp.setDateOfJoining(res.getString("dateOfJoining"));
				emp.setSalary(res.getFloat("salary"));
				employees.add(emp);
				
			}
					
		}catch(Exception e){
			throw new EmployeeException(e);
			
		}
		
		return employees;
	}
	
/*	public static void main(String[] args){
		Employee emp =new Employee();
		//emp.setName("roy");
		emp.setId(95984);
		emp.setDateOfBirth("06/06/1994");
		emp.setDateOfJoining("15/09/2016");
		emp.setDepartment("java");
		emp.setDesignation("Associate");
		emp.setSalary(57000);
		
		EmployeeDAO eDao= new EmployeeDAOImpl();
		
		try {
			eDao.removeEmployee(emp);
		} catch (EmployeeException e) {
			
			e.printStackTrace();
		}
	}*/

}
