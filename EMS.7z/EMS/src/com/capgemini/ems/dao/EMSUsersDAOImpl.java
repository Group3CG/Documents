package com.capgemini.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.capgemini.ems.dto.User;
import com.capgemini.ems.exception.UserException;
import com.capgemini.ems.factory.DBUtil;

public class EMSUsersDAOImpl implements EMSUsersDAO {

	@Override
	public void addUser(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void listUsers() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean validateUser(User user) throws UserException {
		try(Connection con=DBUtil.getConnection()){
			PreparedStatement pstm
			=con.prepareStatement
			("select * from emsusers where username=? and password=?");
			
			pstm.setString(1, user.getUsername());
			pstm.setString(2,user.getPassword());
			
			ResultSet res=pstm.executeQuery();
			
			if(res.next()==false){
				throw new UserException("Username or password is wrong");
			}
			else{
				return true;
			}
			
			
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		} 
		
	}
	
/*	public static void main(String[] args)
	{
		EMSUsersDAO emsUsersDAO= new EMSUsersDAOImpl();
		User user=new User("lalak","pass123");
		
		try {
			System.out.println(emsUsersDAO.validateUser(user));
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/

}
