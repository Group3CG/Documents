package com.capgemini.ems.dao;

import java.util.List;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmployeeException;

public interface EmployeeDAO {
	public void  addEmployee(Employee emp) throws EmployeeException;
	public void updateEmployee(Employee emp)  throws EmployeeException;
	public Employee searchEmployee(Employee emp) throws EmployeeException;
	public void removeEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getAllEmployees() throws EmployeeException;
	

}
