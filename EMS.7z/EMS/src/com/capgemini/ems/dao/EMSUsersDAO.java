package com.capgemini.ems.dao;

import com.capgemini.ems.dto.User;
import com.capgemini.ems.exception.UserException;

public interface EMSUsersDAO {
	public void addUser(User user);
	public void listUsers();
	public boolean validateUser(User user) throws UserException;

}
