package com.capgemini.ems.exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
		
	}

	public EmployeeException(String message) {
		super(message);
		
	}

	public EmployeeException(Throwable cause) {
		super(cause);
		
	}
	

	

}
