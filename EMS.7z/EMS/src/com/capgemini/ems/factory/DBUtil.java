package com.capgemini.ems.factory;

import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {
	public static Connection getConnection() throws ClassNotFoundException, SQLException{
		/*Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@NDAOracle.igatecorp.com:1521:orcl11g",
				"Lab1102trg19", "lab1102oracle");
		
		return con;*/
		Connection connection=null;
		try{
			InitialContext context= new InitialContext();
			
			DataSource source=(DataSource) context.lookup("java:/OracleDS/MyDS");
			
			connection =source.getConnection();
		}catch(Exception e){
			
		}
		return connection;
		
	}
/*	public static void main(String[] args){
		try{
			Connection con=getConnection();
			System.out.println(con);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/

}
