package com.capgemini.ems.test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;




import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.factory.DBUtil;

public class JUnitTest extends TestCase {
	Connection conn=null;
	
	PreparedStatement pstm;
	
	@Before
	public void doBefore() throws EmployeeException,
		SQLException, ClassNotFoundException{
			
		conn=DBUtil.getConnection();
		
		pstm=conn.prepareStatement("INSERT INTO EMPLOYEE VALUES(?,?,?,?,?,?,?)");
		
		pstm.setInt(1, 1001);
		pstm.setString(2,"ABCD" );
		pstm.setString(3,"JAVA");
		pstm.setString(4,"Cd");
		pstm.setString(5,"Cd");
		pstm.setString(6,"Cd");
		pstm.setFloat(7,123);
		
		}
		
	

	@Test
	public void doTest() throws SQLException {
		assertEquals(1,pstm.executeUpdate() );
	}
	@After
	public void doAfter()throws SQLException{
		conn.close();
	}
}
