package com.capgemini.ems.service;

import java.util.HashMap;
import java.util.List;
import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.exception.UserException;

public interface EmployeeService {
	public void  addEmployee(HashMap<String,String> empDetails) throws EmployeeException;
	public void updateEmployee(HashMap<String,String> empDetails)  throws EmployeeException;
	public HashMap<String,String> searchEmployee(String id) throws EmployeeException;
	public void removeEmployee(String id) throws EmployeeException;
	public List<HashMap<String,String>> getAllEmployees() throws EmployeeException;
	
	public boolean validateUser(String username,String password)throws UserException;
}
