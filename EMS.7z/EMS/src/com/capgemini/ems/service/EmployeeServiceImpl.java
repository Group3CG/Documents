package com.capgemini.ems.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.capgemini.ems.dao.EMSUsersDAO;
import com.capgemini.ems.dao.EMSUsersDAOImpl;
import com.capgemini.ems.dao.EmployeeDAO;
import com.capgemini.ems.dao.EmployeeDAOImpl;
import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.dto.User;
import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.exception.UserException;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO employeeDAO;
	private EMSUsersDAO emsUsersDAO;
	
	public EmployeeServiceImpl() {
		employeeDAO=new EmployeeDAOImpl();
		emsUsersDAO= new EMSUsersDAOImpl();
		
	}
	
	

	@Override
	public void addEmployee(HashMap<String, String> empDetails)
			throws EmployeeException {
		Employee emp=new Employee();
		//emp.setId(Integer.parseInt(empDetails.get("id")));
		emp.setName(empDetails.get("name"));
		emp.setDepartment(empDetails.get("department"));
		emp.setDesignation(empDetails.get("designation"));
		emp.setDateOfBirth(empDetails.get("dateOfBirth"));
		emp.setDateOfJoining(empDetails.get("dateOfJoining"));
		emp.setSalary(Float.parseFloat(empDetails.get("salary")));
		
		employeeDAO.addEmployee(emp);

	}

	@Override
	public void updateEmployee(HashMap<String, String> empDetails)
			throws EmployeeException {
		Employee emp=new Employee();
		emp.setId(Integer.parseInt(empDetails.get("id")));
		emp.setName(empDetails.get("name"));
		emp.setDepartment(empDetails.get("department"));
		emp.setDesignation(empDetails.get("designation"));
		emp.setDateOfBirth(empDetails.get("dateOfBirth"));
		emp.setDateOfJoining(empDetails.get("dateOfJoining"));
		emp.setSalary(Float.parseFloat(empDetails.get("salary")));
		
		employeeDAO.updateEmployee(emp);

	}

	@Override
	public HashMap<String, String> searchEmployee(String id)
			throws EmployeeException {
		Employee emp=new Employee();
		emp.setId(Integer.parseInt(id));
		
		emp=employeeDAO.searchEmployee(emp);
		
		HashMap<String, String> empDetails=new HashMap<String, String>();
		empDetails.put("id", String.valueOf(emp.getId()));
		empDetails.put("name",emp.getName());
		empDetails.put("department",emp.getDepartment());
		empDetails.put("designation",emp.getDesignation());
		empDetails.put("dateOfBirth",emp.getDateOfBirth());
		empDetails.put("dateOfJoining",emp.getDateOfJoining());
		empDetails.put("salary",emp.getSalary() + "");
		return empDetails;
	}

	@Override
	public void removeEmployee(String id) throws EmployeeException {
		Employee emp=new Employee();
		emp.setId(Integer.parseInt(id));
		
		employeeDAO.removeEmployee(emp);

	}

	@Override
	public List<HashMap<String, String>> getAllEmployees()
			throws EmployeeException {
		ArrayList<HashMap<String, String>> employees=new ArrayList<>();
		
		List<Employee> emps=employeeDAO.getAllEmployees();
		for(int index=0; index<emps.size();index++){
			Employee emp=emps.get(index);
			
			HashMap<String, String> empDetails=new HashMap<String, String>();
			
			empDetails.put("id", String.valueOf(emp.getId()));
			empDetails.put("name",emp.getName());
			empDetails.put("department",emp.getDepartment());
			empDetails.put("designation",emp.getDesignation());
			empDetails.put("dateOfBirth",emp.getDateOfBirth());
			empDetails.put("dateOfJoining",emp.getDateOfJoining());
			empDetails.put("salary",emp.getSalary() + "");
			
			employees.add(empDetails);
		}
		return employees;
	}

	@Override
	public boolean validateUser(String username, String password)
			throws UserException {
		User user=new User(username,password);
		return emsUsersDAO.validateUser(user);
	}

	
	

}
