function validateAllData()
{
	var firstNameData=window.document.form1.txtFName.value;   //name value is stored in name data
	var lastNameData=window.document.form1.txtLName.value;  
	var contactData=window.document.form1.txtContact.value;
	var emailData=window.document.form1.txtEmail.value;
	var dobData=window.document.form1.txtDate.value;
	var cityData=window.document.form1.txtLocation.value;
	var state;
	if(cityData=="Chennai"){
		state="TamilNadu";
	}
	else if(cityData=="Mumbai"){
		state="Maharashtra";
	}
	else if(cityData=="Pune"){
		state="Maharashtra";
	}
	else{
		state="Karnataka";
	}
	var data="FIRST NAME IS : "+firstNameData+"\n"+"LAST NAME IS : "+lastNameData+"\n"+
	" Contact Number : "+contactData+"\n Email address : "+emailData+"\n Date of Birth : "+dobData+
	"\nCurrent City/Location : "+cityData+"\n State : "+state;
	
	var cgWinObj=window.open("","CgWindow","width=300,height=300");
	cgWinObj.document.write("<body>");
	cgWinObj.document.write(data);
	cgWinObj.document.write("</body>");
	return true;
}