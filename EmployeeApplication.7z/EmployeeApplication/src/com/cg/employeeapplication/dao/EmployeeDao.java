package com.cg.employeeapplication.dao;

import java.util.List;

import com.cg.employeeapplication.dto.Employee;
import com.cg.employeeapplication.exception.EmployeeException;

public interface EmployeeDao {
	
	public int addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> showAll() throws EmployeeException;
	public Employee searchData(Employee emp) throws EmployeeException;
	public void sortData();

}
