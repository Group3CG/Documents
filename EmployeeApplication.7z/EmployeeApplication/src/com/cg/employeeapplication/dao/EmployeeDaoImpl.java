package com.cg.employeeapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.employeeapplication.dto.Employee;
import com.cg.employeeapplication.exception.EmployeeException;
import com.cg.employeeapplication.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao {
private static final Logger myLogger=Logger.getLogger(EmployeeDaoImpl.class);
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		Connection con=null;
		int data=0;
		int empId=getSeqEmpID();
	try {
		con=DbUtil.getConnection();
		String query="INSERT INTO EMPLOYEEDATA VALUES(?,?,?,?)";
		PreparedStatement pstm=con.prepareStatement(query);
		pstm.setInt(1, empId);
		pstm.setString(2,emp.getEmpName() );
		pstm.setString(3,emp.getEmpDep());
		pstm.setDouble(4,emp.getEmpSalary());
		int status=pstm.executeUpdate();
		if (status==1){
			data=empId;
			myLogger.info("Data inserted id..."+data);
		}
	} catch (EmployeeException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new EmployeeException("problem in connection............");
	}finally{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("problem in close");
		}
		
	}
	return data;
		
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		List<Employee> myList=new ArrayList<Employee>();
		Connection conn=null;
	try {
		 conn=DbUtil.getConnection();
		String quer1="SELECT * FROM EMPLOYEEDATA";
		Statement stml=conn.createStatement();
		ResultSet res=stml.executeQuery(quer1);
		while(res.next()){
			Employee emp=new Employee();
			emp.setEmpId(res.getInt("emp_id"));
			emp.setEmpName(res.getString("emp_name"));
			emp.setEmpDep(res.getString("emp_dep"));
			emp.setEmpSalary(res.getDouble("emp_sal"));
			myList.add(emp);
		}
		myLogger.info("List of data.."+myList);
		
	} catch (EmployeeException | SQLException e) {
		myLogger.info("Error Message"+e.getMessage(),e);
		throw new EmployeeException("show errors");
	}finally{
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	return myList;
	}

	@Override
	public Employee searchData(Employee emp) throws EmployeeException {
		Connection conn1=null;
		String query3="SELECT * FROM EMPLOYEEDATA WHERE emp_id=?";
		Employee e=new Employee();
		try {
			conn1=DbUtil.getConnection();
			PreparedStatement ps=conn1.prepareStatement(query3);
			ps.setInt(1,emp.getEmpId());
			ResultSet res= ps.executeQuery();
		
			while(res.next()){
				e.setEmpId(res.getInt("emp_id"));
				e.setEmpName(res.getString("emp_name"));
				e.setEmpDep(res.getString("emp_dep"));
				e.setEmpSalary(res.getDouble("emp_sal"));
				break;
				
			}
		} catch (EmployeeException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw new EmployeeException("Search Error");
		}finally{
			try {
				conn1.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return e;
		
	}
	
	public static int getSeqEmpID(){
		int empId=0;
		String query4="SELECT emp_id_seq.nextval FROM DUAL";
		Connection con=null;
		try {
			con=DbUtil.getConnection();
			Statement st=con.createStatement();
			ResultSet res=st.executeQuery(query4);
			while(res.next()){
				empId=res.getInt(1);
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return empId;
	}

	@Override
	public void sortData() {
		// TODO Auto-generated method stub
		
	}
	
	
	//static database
	
	/*List<Employee> myList=new ArrayList<Employee>();
	

	@Override
	public void addEmployee(Employee emp) {
		myList.add(emp);

	}

	@Override
	public List<Employee> showAll() {
	
		return myList;
	}

	@Override
	public void removeData(Employee emp) {
		for(Employee employee:myList){
			if(employee.getEmpId()==emp.getEmpId()){
				myList.remove(employee);
				break;
			}
		}
		

	}

	@Override
	public void sortData() {
		// TODO Auto-generated method stub

	}*/

}
