package com.cg.employeeapplication.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeeapplication.dao.EmployeeDao;
import com.cg.employeeapplication.dao.EmployeeDaoImpl;
import com.cg.employeeapplication.dto.Employee;
import com.cg.employeeapplication.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDao empDao=new EmployeeDaoImpl();

	@Override
	public int addEmployee(Employee emp)throws EmployeeException {
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll()throws EmployeeException {
	
		return empDao.showAll();
	}

	@Override
	public Employee searchData(Employee emp)throws EmployeeException {
		return empDao.searchData(emp);
	}

	@Override
	public void sortData() {
		// TODO Auto-generated method stub

	}
	
	public static void validateName(String regex,String jname) throws EmployeeException{
		boolean msg=Pattern.matches(regex, jname);
		if(!msg){
			throw new EmployeeException("Employee Name should start with capital letters and contain min 3 and max 15");
		}
	}

}
