package com.cg.employeeapplication.ui;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.cg.employeeapplication.dto.Employee;
import com.cg.employeeapplication.exception.EmployeeException;
import com.cg.employeeapplication.service.EmployeeService;
import com.cg.employeeapplication.service.EmployeeServiceImpl;

public class EmployeeTest {

	public static void main(String[] args){
		int choice=0;
		EmployeeService empService=new EmployeeServiceImpl();
		do{
			Scanner sc=new Scanner(System.in);
			printDetail();
			System.out.println("Enter the choice");
			choice=sc.nextInt();
			switch(choice){
			case 1:
				String patt="[A-Z][a-z]{2,14}";
			/*	System.out.println("enter the employee id");
				int empId=sc.nextInt();*/
				System.out.println("enter the employee name");
				String empName=sc.next();
				try{
				EmployeeServiceImpl.validateName(patt, empName);
				}catch(EmployeeException e){
					//e.printStackTrace();
					System.out.println(e.getMessage());
				}
				System.out.println("enter the employee salary");
				double empSalary=sc.nextDouble();
				System.out.println("enter the employee department");
				String empDep=sc.next();
				Employee emp=new Employee();
				//emp.setEmpId(empId);
				emp.setEmpName(empName);
				emp.setEmpSalary(empSalary);
				emp.setEmpDep(empDep);
				try {
					int id=empService.addEmployee(emp);
					System.out.println("data inserted &empId is "+id);
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				List<Employee> showData;
				try {
					showData = empService.showAll();
					for(Employee employee:showData){
						System.out.println("Id is "+employee.getEmpId());
						System.out.println("Name is "+employee.getEmpName());
						System.out.println("Salary is "+employee.getEmpSalary());
						System.out.println("Department is "+employee.getEmpDep());
					}
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
					
				}
				
				break;
			case 3:
				System.out.println("Enter the employee Id whose details has to be searched");
				int empIdr=sc.nextInt();
				Employee empR=new Employee();
				empR.setEmpId(empIdr);
				try {
					//System.out.println(empService.searchData(empR));
					Employee em=empService.searchData(empR);
					System.out.println("Name is : "+em.getEmpName());
					System.out.println("Dep is : "+em.getEmpDep());
					System.out.println("salary is :"+em.getEmpSalary());
				} catch (EmployeeException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					System.out.println(e1.getMessage());
				}
				
				break;
			case 4:
				List<Employee> sortData;
				try {
					sortData = empService.showAll();
					Collections.sort(sortData);
					for(Employee employee:sortData){
						System.out.println("Id is "+employee.getEmpId());
						System.out.println("Name is "+employee.getEmpName());
						System.out.println("Salary is "+employee.getEmpSalary());
						System.out.println("Department is "+employee.getEmpDep());
					}	
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				
				break;
			case 5:
				System.out.println("thanks");
				System.exit(0);
				
				break;
			}
			
		}while(choice!=5);
		

	}
	public static void printDetail(){
		System.out.println("****************Employee Database***********************");
		System.out.println("1. Add Employee");
		System.out.println("2. Show All");
		System.out.println("3. Search Employee");
		System.out.println("4. Sort Employee ");
		System.out.println("5. Exit");
		System.out.println("*********************************************************");
	}
	
	
}
