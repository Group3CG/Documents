package com.cg.employeeapplication.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;


import com.cg.employeeapplication.exception.EmployeeException;

public class DbUtil {
	static Connection con=null;
	private static final Logger myLog=Logger.getLogger(DbUtil.class);
	public static Connection getConnection() throws EmployeeException {
		try {
			FileInputStream fileRead=new FileInputStream("oracle.properties");
			Properties prop =new Properties();
			prop.load(fileRead);
			String driver=prop.getProperty("oracle.driver");
			String url=prop.getProperty("oracle.url");
			String uname=prop.getProperty("oracle.username");
			String upass=prop.getProperty("oracle.password");
			Class.forName(driver);
			con=DriverManager.getConnection(url, uname, upass);
			//System.out.println("Connection done............");
			myLog.info("Connected with DB");
			
		} catch (IOException | ClassNotFoundException | SQLException e) {
			myLog.info("Not Connected"+e.getMessage());
			throw new EmployeeException("Connection not established............");
		}
		return con;
	}

}
