package com.cg.employeeapplication.junittest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.employeeapplication.dao.EmployeeDaoImpl;
import com.cg.employeeapplication.exception.EmployeeException;
import com.cg.employeeapplication.util.DbUtil;

public class DaoImplTest {
	Connection conn=null;
	EmployeeDaoImpl empImpl=null;
	PreparedStatement pstm;
	
	@Before
	public void doBefore() throws EmployeeException,
		SQLException{
			String query="INSERT INTO EMPLOYEEDATA VALUES(?,?,?,?)";
		conn=DbUtil.getConnection();
		
		pstm=conn.prepareStatement(query);
		
		
		pstm.setInt(1, 1008);
		pstm.setString(2,"ABCD" );
		pstm.setString(3,"JAVA");
		pstm.setDouble(4,2019.56);
		}
		
	

	@Test
	public void doTest() throws SQLException {
		assertEquals(1,pstm.executeUpdate() );
	}
	@After
	public void doAfter()throws SQLException{
		conn.close();
		
	}

}
